from django.shortcuts import render
from .forms import FbForm

def home(request):
    if request.method == "POST":
        data = FbForm(request.POST)
        if data.is_valid():
            data.save()
            msg = "Thank you for your feedback"
            fm = FbForm()
            return render(request, "home.html", {"fm":fm, "msg":msg})
        else:
            msg = "Issue"
            return render(request, "home.html", {"fm":data, "msg":msg})
    else:
        fm = FbForm()
        return render(request, "home.html", {"fm":fm})
