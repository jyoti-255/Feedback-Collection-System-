from django.contrib import admin
from .models import FbModel

class FbAdmin(admin.ModelAdmin):
     list_display=("name","crdt")
     list_filter=("crdt",) #must use this comma agar ham bas single element use kar rahe hai

admin.site.register(FbModel,FbAdmin)
