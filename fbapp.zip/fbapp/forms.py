from django import forms
from .models import FbModel

class FbForm(forms.ModelForm):
    class Meta:
        model = FbModel
        fields = ["name", "feedback"]
        widgets = {
            "feedback": forms.Textarea(attrs={'rows': 4, 'cols': 22, 'style': 'resize:none'})
        }

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if len(name) < 2:
            raise forms.ValidationError("Name should contain at least 2 characters.")
        if not name.isalpha():
            raise forms.ValidationError("Name should contain only alphabets.")
        return name

    def clean_feedback(self):
        feedback = self.cleaned_data.get('feedback')
        if len(feedback) < 20:
            raise forms.ValidationError("Feedback should contain at least 20 characters.")
        return feedback

